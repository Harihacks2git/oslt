#include <stdio.h>
#include <stdlib.h>
struct Process {
	int pid;
	int burst_time;
	int priority;
};
int compare(const void* a, const void* b) {
	struct Process* procA = (struct Process*)a;
	struct Process* procB = (struct Process*)b;
	return procA->priority - procB->priority;
}
void findWaitingTime(struct Process proc[], int n, int wt[]) {
	wt[0] = 0;
	for (int i = 1; i < n; i++) {
		wt[i] = proc[i - 1].burst_time + wt[i - 1];
	}
}
void findTurnAroundTime(struct Process proc[], int n, int wt[], int tat[]) {
	for (int i = 0; i < n; i++) {
		tat[i] = proc[i].burst_time + wt[i];
	}
}
void findAvgTime(struct Process proc[], int n) {
	int wt[n], tat[n], total_wt = 0, total_tat = 0;
	findWaitingTime(proc, n, wt);
	findTurnAroundTime(proc, n, wt, tat);
	printf("\nProcesses\tBurst Time\tWaiting Time\tTurnaround Time\n");
	for (int i = 0; i < n; i++) {
		total_wt += wt[i];
		total_tat += tat[i];
		printf("%d\t\t%d\t\t%d\t\t%d\n", proc[i].pid, proc[i].burst_time, wt[i], tat[i]);
	}
	printf("\nAverage Waiting Time: %.2f\n", (float)total_wt / n);
	printf("Average Turnaround Time: %.2f\n", (float)total_tat / n);
}
void priorityScheduling(struct Process proc[], int n) {
	qsort(proc, n, sizeof(struct Process), compare);
	printf("Order in which processes get executed:\n");
	for (int i = 0; i < n; i++) {
		printf("P%d ", proc[i].pid);
	}
	findAvgTime(proc, n);
}
int main() {
	int n;
	printf("\n Enter the no of process : ");
	scanf("%d",&n);
	struct Process p[n];
	for(int i=0;i<n;i++)
	{
		p[i].pid = i+1;
		printf("\n Burst time and Priority for P%d : ",i+1);
		scanf("%d%d",&p[i].burst_time,&p[i].priority);
	}
	priorityScheduling(p, n);
	return 0;
}
