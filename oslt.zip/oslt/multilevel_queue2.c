#include <stdio.h>
#include <stdlib.h>

#define MAX 10

typedef struct {
    int id;
    int burst_time;
    int priority;
} Process;

void sort_by_priority(Process p[], int n) {
    Process temp;
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            if (p[i].priority > p[j].priority) {
                temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
    }
}

void fcfs(Process p[], int n) {
    printf("\nFirst Come First Serve Scheduling:\n");
    int waiting_time = 0;
    for (int i = 0; i < n; i++) {
        printf("Process ID: %d, Waiting Time: %d\n", p[i].id, waiting_time);
        waiting_time += p[i].burst_time;
    }
}

void round_robin(Process p[], int n, int quantum) {
    printf("\nRound Robin Scheduling:\n");
    int time = 0;
    int remaining_burst_time[MAX];
    for (int i = 0; i < n; i++) {
        remaining_burst_time[i] = p[i].burst_time;
    }

    while (1) {
        int done = 1;
        for (int i = 0; i < n; i++) {
            if (remaining_burst_time[i] > 0) {
                done = 0;
                if (remaining_burst_time[i] > quantum) {
                    time += quantum;
                    remaining_burst_time[i] -= quantum;
                } else {
                    time += remaining_burst_time[i];
                    printf("Process ID: %d, Waiting Time: %d\n", p[i].id, time - p[i].burst_time);
                    remaining_burst_time[i] = 0;
                }
            }
        }
        if (done == 1) break;
    }
}

int main() {
    int n;
    Process processes[MAX];

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    for (int i = 0; i < n; i++) {
        processes[i].id = i + 1;
        printf("Enter burst time and priority for process %d: ", i + 1);
        scanf("%d %d", &processes[i].burst_time, &processes[i].priority);
    }

    sort_by_priority(processes, n);

    int high_priority_count = 0;
    for (int i = 0; i < n; i++) {
        if (processes[i].priority == 1) {
            high_priority_count++;
        } else {
            break;
        }
    }

    fcfs(processes, high_priority_count);
    round_robin(processes + high_priority_count, n - high_priority_count, 2);

    return 0;
}

