#!/bin/bash

# Array of 20 words
words=("apple" "banana" "cat" "dog" "elephant" "fish" "gorilla" "hat" "ice" "jungle" "kangaroo" "lion" "mango" "nest" "orange" "penguin" "queen" "rabbit" "snake" "tiger")

# Function to reverse and list alternate words
reverse_alternate() {
    for (( i=${#words[@]}-1; i>=0; i-=2 )); do
        echo "${words[i]}"
    done
}

# Function to list words with less than 4 characters count
less_than_four() {
    for word in "${words[@]}"; do
        if [ ${#word} -lt 4 ]; then
            echo "$word"
        fi
    done
}

# Function to list words beginning with 'e'
starts_with_e() {
    for word in "${words[@]}"; do
        if [[ $word == e* ]]; then
            echo "$word"
        fi
    done
}

# Main menu
while true; do
    echo "1. Reverse and list alternate words"
    echo "2. List the words with less than 4 characters count"
    echo "3. List words beginning with 'e'"
    echo "4. Exit"
    read -p "Enter your choice: " choice

    case $choice in
        1) reverse_alternate ;;
        2) less_than_four ;;
        3) starts_with_e ;;
        4) exit ;;
        *) echo "Invalid choice. Please choose again." ;;
    esac
done