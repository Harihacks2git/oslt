#!/bin/bash

# Create a list of 20 words
words=("apple" "banana" "orange" "umbrella" "ant" "ink" "elephant" "under" "ostrich" "ice" "dog" "cat" "fish" "bird" "lion" "tiger" "cheetah" "hawk" "leopard" "dolphin")

# Function to list words beginning with vowels
list_vowel_words() {
    echo "Words beginning with vowels:"
    for word in "${words[@]}"; do
        if [[ $word =~ ^[aeiouAEIOU] ]]; then
            echo "$word"
        fi
    done
}

# Function to list words with even character count
list_even_length_words() {
    echo "Words with even character count:"
    for word in "${words[@]}"; do
        if (( ${#word} % 2 == 0 )); then
            echo "$word"
        fi
    done
}

# Function to list words ending with 'd'
list_words_ending_d() {
    echo "Words ending with 'd':"
    for word in "${words[@]}"; do
        if [[ $word =~ d$ ]]; then
            echo "$word"
        fi
    done
}

# Menu function
menu() {
    echo "Select an option:"
    echo "1. List words beginning with vowels"
    echo "2. List words with even character count"
    echo "3. List words ending with 'd'"
    echo "4. Exit"
    read -p "Enter your choice: " choice

    case $choice in
        1) list_vowel_words ;;
        2) list_even_length_words ;;
        3) list_words_ending_d ;;
        4) exit 0 ;;
        *) echo "Invalid option. Please try again." ;;
    esac
}

# Main loop
while true; do
    menu
done
