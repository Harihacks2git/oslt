#include <stdio.h>                                                                                                                                                                                                 
struct process {                                                                                                                                                                                                   
	int pid;                                                                                                                                                                                                   
	int at;                                                                                                                                                                                                    
	int bt;                                                                                                                                                                                                    
	int st;                                                                                                                                                                                                    
	int ct;                                                                                                                                                                                                    
	int tat;                                                                                                                                                                                                   
	int wt;                                                                                                                                                                                                    
	int rt;                                                                                                                                                                                                    
};                                                                                                                                                                                                                 
int main() {                                                                                                                                                                                                       
	int x;                                                                                                                                                                                                     
	struct process p[100];                                                                                                                                                                                     
	float avg_tat;                                                                                                                                                                                             
	float avg_wt;                                                                                                                                                                                              
	int total_tat = 0;                                                                                                                                                                                         
	int total_wt = 0;                                                                                                                                                                                          
	int burst_remaining[100] = {0};                                                                                                                                                                            
	int is_completed[100] = {0};                                                                                                                                                                               
	printf("Enter the number of processes: ");                                                                                                                                                                 
	scanf("%d", &x);                                                                                                                                                                                           
	for (int i = 0; i < x; i++) {                                                                                                                                                                              
		printf("Enter arrival time of process %d: ", i + 1);                                                                                                                                               
		scanf("%d", &p[i].at);                                                                                                                                                                             
		printf("Enter burst time of process %d: ", i + 1);                                                                                                                                                 
		scanf("%d", &p[i].bt);                                                                                                                                                                             
		p[i].pid = i + 1;                                                                                                                                                                                  
		burst_remaining[i] = p[i].bt;                                                                                                                                                                      
	}                                                                                                                                                                                                          
	int current_time = 0;                                                                                                                                                                                      
	int completed = 0;                                                                                                                                                                                         
	int prev = 0;                                                                                                                                                                                              
	while (completed != x) {                                                                                                                                                                                   
		int idx = -1;                                                                                                                                                                                      
		int mn = 10000000;                                                                                                                                                                                 
		for (int i = 0; i < x; i++) {                                                                                                                                                                      
			if (p[i].at <= current_time && is_completed[i] == 0) {                                                                                                                                     
				if (burst_remaining[i] < mn) {                                                                                                                                                     
					mn = burst_remaining[i];                                                                                                                                                   
					idx = i;                                                                                                                                                                   
				}                                                                                                                                                                                  
				if (burst_remaining[i] == mn) {                                                                                                                                                    
					if (p[i].at < p[idx].at) {                                                                          
						mn = burst_remaining[i];                                                                                                                                           
						idx = i;                                                                                                                                                           
					}                                                                                                                                                                          
				}                                                                                                                                                                                  
			}                                                                                                                                                                                          
		}                                                                                                                                                                                                  
		if (idx != -1) {                                                                                                                                                                                   
			if (burst_remaining[idx] == p[idx].bt) {                                                                                                                                                   
				p[idx].st = current_time;                                                                                                                                                          
			}                                                                                                                                                                                          
			burst_remaining[idx]--;                                                                                                                                                                    
			current_time++;                                                                                             
			if (burst_remaining[idx] == 0) {                                                                                                                                                           
				p[idx].ct = current_time;                                                                                                                                                          
				p[idx].tat = p[idx].ct - p[idx].at;                                                                                                                                                
				p[idx].wt = p[idx].tat - p[idx].bt;                                                                                                                                                
				total_tat += p[idx].tat;                                                                                                                                                           
				total_wt += p[idx].wt;                                                                                                                                                             
				is_completed[idx] = 1;                                                                                                                                                             
				completed++;                                                                                                                                                                       
			}                                                                                                                                                                                          
		} else {                                                                                                                                                                                           
			current_time++;                                                                                                                                                                            
		}                                                                                                                                                                                                  
	}                                                                                                                                                                                                          
	avg_tat = (float) total_tat / x;                                                                                                                                                                           
	avg_wt = (float) total_wt / x;                                                                                                                                                                             
	printf("\nProcess\tTurnaround Time\tWaiting Time\n");                                                                                                                                                      
	for (int i = 0; i < x; i++) {                                                                                                                                                                              
		printf("%d\t%d\t\t%d\n", p[i].pid, p[i].tat, p[i].wt);                                                                                                                                             
	}                                                                                                                                                                                                          
	printf("Average Turnaround Time: %.2f\n", avg_tat);                                                                                                                                                        
	printf("Average Waiting Time: %.2f\n", avg_wt);                                                                                                                                                            
	return 0;                                                                                                                                                                                                  
}
