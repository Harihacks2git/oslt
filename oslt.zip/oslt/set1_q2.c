#include <stdio.h>
#include <limits.h>

typedef struct {
    int pid;            // Process ID
    int arrivalTime;
    int burstTime;
    int remainingTime;  // Used for SJF
    int waitingTime;
    int turnaroundTime;
    int completionTime; // Used for SJF
} Process;

void sortProcessesByArrivalTime(Process proc[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (proc[j].arrivalTime > proc[j + 1].arrivalTime) {
                Process temp = proc[j];
                proc[j] = proc[j + 1];
                proc[j + 1] = temp;
            }
        }
    }
}

void calculateFIFO(Process proc[], int n) {
    sortProcessesByArrivalTime(proc, n);

    proc[0].waitingTime = 0;
    proc[0].completionTime = proc[0].arrivalTime + proc[0].burstTime;
    proc[0].turnaroundTime = proc[0].burstTime;

    for (int i = 1; i < n; i++) {
        proc[i].waitingTime = proc[i-1].completionTime - proc[i].arrivalTime;
        if (proc[i].waitingTime < 0) {
            proc[i].waitingTime = 0;
        }
        proc[i].completionTime = proc[i].arrivalTime + proc[i].waitingTime + proc[i].burstTime;
        proc[i].turnaroundTime = proc[i].completionTime - proc[i].arrivalTime;
    }

    int totalWaitingTime = 0, totalTurnaroundTime = 0;
    printf("FIFO Scheduling:\n");
    printf("PID\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        totalWaitingTime += proc[i].waitingTime;
        totalTurnaroundTime += proc[i].turnaroundTime;
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", proc[i].pid, proc[i].arrivalTime, proc[i].burstTime, proc[i].completionTime, proc[i].turnaroundTime, proc[i].waitingTime);
    }

    printf("Average waiting time = %.2f\n", (float)totalWaitingTime / n);
    printf("Average turnaround time = %.2f\n\n", (float)totalTurnaroundTime / n);
}

void calculatePreemptiveSJF(Process proc[], int n) {
    sortProcessesByArrivalTime(proc, n);

    int totalWaitingTime = 0, totalTurnaroundTime = 0;
    int completed = 0, currentTime = 0, minBurst = INT_MAX;
    int shortest = 0, finishTime;
    int check = 0;

    for (int i = 0; i < n; i++) {
        proc[i].remainingTime = proc[i].burstTime;
    }

    while (completed != n) {
        for (int i = 0; i < n; i++) {
            if (proc[i].arrivalTime <= currentTime && proc[i].remainingTime < minBurst && proc[i].remainingTime > 0) {
                minBurst = proc[i].remainingTime;
                shortest = i;
                check = 1;
            }
        }

        if (check == 0) {
            currentTime++;
            continue;
        }

        proc[shortest].remainingTime--;

        minBurst = proc[shortest].remainingTime;
        if (minBurst == 0) {
            minBurst = INT_MAX;
        }

        if (proc[shortest].remainingTime == 0) {
            completed++;
            check = 0;
            finishTime = currentTime + 1;
            proc[shortest].completionTime = finishTime;
            proc[shortest].waitingTime = finishTime - proc[shortest].burstTime - proc[shortest].arrivalTime;

            if (proc[shortest].waitingTime < 0) {
                proc[shortest].waitingTime = 0;
            }
        }
        currentTime++;
    }

    for (int i = 0; i < n; i++) {
        proc[i].turnaroundTime = proc[i].burstTime + proc[i].waitingTime;
        totalWaitingTime += proc[i].waitingTime;
        totalTurnaroundTime += proc[i].turnaroundTime;
    }

    printf("Preemptive SJF Scheduling:\n");
    printf("PID\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", proc[i].pid, proc[i].arrivalTime, proc[i].burstTime, proc[i].completionTime, proc[i].turnaroundTime, proc[i].waitingTime);
    }

    printf("Average waiting time = %.2f\n", (float)totalWaitingTime / n);
    printf("Average turnaround time = %.2f\n", (float)totalTurnaroundTime / n);
}

int main() {
    Process procFIFO[] = {{1, 3, 10}, {2, 0, 6}, {3, 4, 2}, {4, 6, 7}};
    int nFIFO = sizeof(procFIFO) / sizeof(procFIFO[0]);

    Process procSJF[] = {{1, 3, 10}, {2, 0, 6}, {3, 4, 2}, {4, 6, 7}};
    int nSJF = sizeof(procSJF) / sizeof(procSJF[0]);

    // Calculate FIFO
    calculateFIFO(procFIFO, nFIFO);

    // Calculate Preemptive SJF
    calculatePreemptiveSJF(procSJF, nSJF);

    return 0;
}
