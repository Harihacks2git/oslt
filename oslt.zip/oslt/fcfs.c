#include <stdio.h>                                                                                                                                                                                                 
void findWaitingTime(int processes[], int n, int bt[], int wt[], int at[]) {                                                                                                                                       
	int currentTime = 0;                                                                                                                                                                                       
	for (int i = 0; i < n; i++) {                                                                                                                                                                              
		if (currentTime < at[i]) {                                                                                                                                                                         
			currentTime = at[i];                                                                                                                                                                       
		}                                
		wt[i] = currentTime - at[i];                                                                                                                                                                   
		currentTime += bt[i];                                                                                                                                                                              
	}                                                                                                                                                                                                          
}                                                                                                                                                                                                                  
void findTurnAroundTime(int processes[], int n, int bt[], int wt[], int tat[]) {                                                                                                                                   
	for (int i = 0; i < n; i++) {                                                                                                                                                                              
		tat[i] = bt[i] + wt[i];                                                                                                                                                                            
	}                                                                                                                                                                                                          
}                                                                                                                                                                                                                  
void findAverageTime(int processes[], int n, int bt[], int at[]) {                                                                                                                                                 
	int wt[n], tat[n];                                                                                                                                                                                         
	findWaitingTime(processes, n, bt, wt, at);                                                                                                                                                                 
	findTurnAroundTime(processes, n, bt, wt, tat);                                                                                                                                                             
	printf("P\t AT\t BT\t WT\t TAT\n");                                                                                                                                                                        
	int total_wt = 0, total_tat = 0;                                                                                                                                                                           
	for (int i = 0; i < n; i++) {                                                                                                                                                                              
		total_wt += wt[i];                                                                                                                                                                                 
		total_tat += tat[i];                                                                                                                                                                               
		printf("%d\t %d\t %d\t %d\t %d\n", processes[i], at[i], bt[i], wt[i], tat[i]);                                                                                                                     
	}                                                                                                                                                                                                          
	printf("Average waiting time = %.2f\n", (float)total_wt / (float)n);                                                                                                                                       
	printf("Average turnaround time = %.2f\n", (float)total_tat / (float)n);                                                                                                                                   
}                                                                                                                                                                                                                  
int main() {                                                                                                                                                                                                       
	int n;                                                                                                                                                                                                     
	printf("Enter the number of processes: ");                                                                                                                                                                 
	scanf("%d", &n);                                                                                                                                                                                           
	int processes[n], burst_time[n], arrival_time[n];                                                                                                                                                          
	printf("Enter arrival time and burst time for each process:\n");                                                                                                                                           
	for (int i = 0; i < n; i++) {                                                                                                                                                                              
		printf("Process %d: ", i + 1);                                                                                                                                                                     
		scanf("%d %d", &arrival_time[i], &burst_time[i]);                                                                                                                                                  
		processes[i] = i + 1;                                                                                                                                                                              
	}                                                                                                                                                                                                          
	findAverageTime(processes, n, burst_time, arrival_time);                                                                                                                                                   
	return 0;                                                                                                                                                                                                  
}
