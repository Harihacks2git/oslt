#include <stdio.h>
#include <limits.h>

typedef struct {
    int pid;            // Process ID
    int arrivalTime;
    int burstTime;
    int remainingTime;  // Used for Priority
    int priority;       // Priority
    int waitingTime;
    int turnaroundTime;
    int completionTime;
} Process;

void sortProcessesByArrivalTime(Process proc[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (proc[j].arrivalTime > proc[j + 1].arrivalTime) {
                Process temp = proc[j];
                proc[j] = proc[j + 1];
                proc[j + 1] = temp;
            }
        }
    }
}

void calculateNonPreemptiveSJF(Process proc[], int n) {
    sortProcessesByArrivalTime(proc, n);

    int completed = 0, currentTime = 0, minBurst = INT_MAX, shortest = 0, finishTime;
    int check = 0;

    while (completed != n) {
        for (int i = 0; i < n; i++) {
            if (proc[i].arrivalTime <= currentTime && proc[i].burstTime < minBurst && proc[i].completionTime == 0) {
                minBurst = proc[i].burstTime;
                shortest = i;
                check = 1;
            }
        }

        if (check == 0) {
            currentTime++;
            continue;
        }

        finishTime = currentTime + proc[shortest].burstTime;
        proc[shortest].completionTime = finishTime;
        proc[shortest].waitingTime = finishTime - proc[shortest].burstTime - proc[shortest].arrivalTime;

        if (proc[shortest].waitingTime < 0) {
            proc[shortest].waitingTime = 0;
        }

        proc[shortest].turnaroundTime = proc[shortest].completionTime - proc[shortest].arrivalTime;

        minBurst = INT_MAX;
        check = 0;
        completed++;
        currentTime = finishTime;
    }

    int totalWaitingTime = 0, totalTurnaroundTime = 0;
    printf("Non-Preemptive SJF Scheduling:\n");
    printf("PID\tAT\tBT\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        totalWaitingTime += proc[i].waitingTime;
        totalTurnaroundTime += proc[i].turnaroundTime;
        printf("%d\t%d\t%d\t%d\t%d\t%d\n", proc[i].pid, proc[i].arrivalTime, proc[i].burstTime, proc[i].completionTime, proc[i].turnaroundTime, proc[i].waitingTime);
    }

    printf("Average waiting time = %.2f\n", (float)totalWaitingTime / n);
    printf("Average turnaround time = %.2f\n\n", (float)totalTurnaroundTime / n);
}

void calculatePriorityScheduling(Process proc[], int n, int timeQuantum) {
    sortProcessesByArrivalTime(proc, n);

    int totalWaitingTime = 0, totalTurnaroundTime = 0;
    int completed = 0, currentTime = 0;
    int check = 0;

    for (int i = 0; i < n; i++) {
        proc[i].remainingTime = proc[i].burstTime;
    }

    while (completed != n) {
        int highestPriority = -1;
        for (int i = 0; i < n; i++) {
            if (proc[i].arrivalTime <= currentTime && proc[i].remainingTime > 0) {
                if (highestPriority == -1 || proc[i].priority < proc[highestPriority].priority) {
                    highestPriority = i;
                }
            }
        }

        if (highestPriority == -1) {
            currentTime++;
            continue;
        }

        if (proc[highestPriority].remainingTime <= timeQuantum) {
            currentTime += proc[highestPriority].remainingTime;
            proc[highestPriority].remainingTime = 0;
            completed++;
            proc[highestPriority].completionTime = currentTime;
            proc[highestPriority].waitingTime = currentTime - proc[highestPriority].arrivalTime - proc[highestPriority].burstTime;
            if (proc[highestPriority].waitingTime < 0) {
                proc[highestPriority].waitingTime = 0;
            }
        } else {
            proc[highestPriority].remainingTime -= timeQuantum;
            currentTime += timeQuantum;
        }
    }

    for (int i = 0; i < n; i++) {
        proc[i].turnaroundTime = proc[i].burstTime + proc[i].waitingTime;
        totalWaitingTime += proc[i].waitingTime;
        totalTurnaroundTime += proc[i].turnaroundTime;
    }

    printf("Priority Scheduling with Time Quantum of %d ms:\n", timeQuantum);
    printf("PID\tAT\tBT\tP\tCT\tTAT\tWT\n");
    for (int i = 0; i < n; i++) {
        printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\n", proc[i].pid, proc[i].arrivalTime, proc[i].burstTime, proc[i].priority, proc[i].completionTime, proc[i].turnaroundTime, proc[i].waitingTime);
    }

    printf("Average waiting time = %.2f\n", (float)totalWaitingTime / n);
    printf("Average turnaround time = %.2f\n", (float)totalTurnaroundTime / n);
}

int main() {
    Process procSJF[] = {{1, 3, 10,1}, {2, 0, 6,2}, {3, 2,2,3}, {4, 1,7,4}};
    int nSJF = sizeof(procSJF) / sizeof(procSJF[0]);

    Process procPriority[] = {{1, 3, 10,10,1}, {2, 0, 6,6,2}, {3, 2,2,2,3}, {4, 1,7,7,4}};
    int nPriority = sizeof(procPriority) / sizeof(procPriority[0]);

    int timeQuantum = 3;

    // Calculate Non-Preemptive SJF
    calculateNonPreemptiveSJF(procSJF, nSJF);

    // Calculate Priority Scheduling with Time Quantum
    calculatePriorityScheduling(procPriority, nPriority, timeQuantum);

    return 0;
}
