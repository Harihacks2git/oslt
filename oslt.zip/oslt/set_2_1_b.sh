#!/bin/bash

# Create a file with the narrative
cat > breaking_narrative.txt <<EOF
Breaking, commonly known as breakdancing, will be included at the Olympics for the first time in Paris. Breaking is a style of dance that originated in the Bronx in the 1970s. Over the decades, it has evolved into a competitive sport, complete with international events, a robust judging system and world championships. Breaking debuted at the 2018 Youth Olympic Games in Buenos Aires and was chosen for Paris 2024 as a new sport. It will not return for the 2028 Los Angeles Games, but breaking is set for its moment in Paris.
EOF

# Replace 'Paris' with 'Lyon' using sed
sed -i 's/Paris/Lyon/g' breaking_narrative.txt

# Display the 2 lines before the pattern match 'Over' using grep
grep -B 2 'Over' breaking_narrative.txt