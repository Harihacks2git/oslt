#!/bin/bash
echo "Lines matching Mango"
grep -i "Mango" sample2.txt
echo "count and print vowels"
awk '/a/{++cnt}/e/{++cnt}/i/{++cnt}/o/{++cnt}/u/{++cnt}END{print "vowels count=",cnt}' sample2.txt
echo "replace cost with count"
sed 's/cost/count/' sample2.txt
echo "deleting apple"
sed '/Apple/d' sample2.txt
