#!/bin/bash
echo "grep -i ignores case for matching"
grep -i reactJs sample.txt
echo "grep -c No of lines that match pattern"
grep -c Reactjs sample.txt
echo "grep -o print only the matched pattern"
grep -o Reactjs sample.txt
echo "grep -n search a string and print it with the line number"
grep -n Reactjs sample.txt
echo "grep -v display the lie that doesn't contain the string"
grep -v Reactjs sample.txt
echo "display the line that start with the string"
grep  "^Reactjs" sample.txt
echo "display the line that ends with the string"
grep "Reactjs$" sample.txt
