#!/bin/bash
echo "$(ls -lsh)"
