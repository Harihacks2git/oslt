#!/bin/bash
echo " Enter 1 for upper to lower and 2 for lower to upper case"
read ch
read str
case $ch in 
	1)echo $str|tr '[:upper:]' '[:lower:]';;
	2)echo $str|tr '[:lower:]' '[:upper:]';;
esac
	
