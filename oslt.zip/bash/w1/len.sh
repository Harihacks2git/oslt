#!/bin/bash
read -p "Enter string: " n
echo "length is ${#n}"

