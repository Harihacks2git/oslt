#!/bin/bash
read -p "enter the value of n: " n
a=0
b=1
while (($a<$n))
do
	echo $a
	temp=$((a+b))
	a=$b
	b=$temp
done

