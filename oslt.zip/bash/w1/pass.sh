#!/bin/bash
chars=[:alnum:]
password=$(tr -dc "$chars" < /dev/random | head -c 8)
echo $password
