#!/bin/bash
read -p "enter a number: " n
echo "Reversed number :$(echo $n | rev)"
