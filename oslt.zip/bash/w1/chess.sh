#!/bin/bash
for (( row=1;row<=8;row++ ));do
	for ((col=1;col<=8;col++ ));do
		if (((row+col) %2 == 0));then
			echo -ne "\e[47m "
		else
			echo -ne "\e[40m "
		fi
	done
	echo -e "\e[0m"
done
