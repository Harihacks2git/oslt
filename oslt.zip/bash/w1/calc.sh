#!/bin/bash
read -p "Enter the operand1: " a
read -p "Enter the operand2: " b
read -p "Enter the operator: " operator
result=$(($a$operator$b))
echo "$a$operator$b = $result"
