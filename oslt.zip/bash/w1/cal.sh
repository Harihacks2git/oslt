#!/bin/bash
echo calender | cal $1 $2 $3

