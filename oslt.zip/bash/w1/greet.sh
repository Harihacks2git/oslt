#!/bin/bash
hour=$(date +%H)
if [ $hour -lt 12 -a $hour -gt 0 ];then
	echo "Good Morning!"
elif [ $hour -lt 18 -a $hour -gt 12 ];then
	echo "Good evening!"
else
	echo "Good Night!"
fi
