#!/bin/bash
l=1
for((i=0;i<5;i++));
do
	for((j=5-i;j>0;j--));
	do
		echo -n " "
	done
		for((k=0;k<l;k++))
		do
			echo -n "*"
		done
		l=$((l+2))
		echo ""
	done
