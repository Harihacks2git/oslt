#!/bin/bash
read -p "Enter the first number:" a
read -p "Enter the second number:" b
sum=$((a+b))
echo "Sum of two number is $sum"
