#!/bin/bash
read -p "Enter the value of n:" n
power=$((2**n))
echo "numbers in the power of 2"
for((i=1;i<=power;i*=2))
do
	echo $i
done
