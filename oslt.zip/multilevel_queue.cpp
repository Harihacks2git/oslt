#include <iostream>
#include <queue>
#include <vector>

using namespace std;

class Process {
public:
    int pid; // Process ID
    int priority; // Priority level
    int burstTime; // Burst time

    Process(int p, int pr, int bt) : pid(p), priority(pr), burstTime(bt) {}
};

// Function to simulate process execution
void executeProcess(Process p) {
    cout << "Executing Process ID: " << p.pid << " with priority: " << p.priority << " and burst time: " << p.burstTime << " ms" << endl;
}

int main() {
    // Create separate queues for each priority level
    queue<Process> highPriorityQueue;
    queue<Process> mediumPriorityQueue;
    queue<Process> lowPriorityQueue;

    int numberOfProcesses;
    cout << "Enter the number of processes: ";
    cin >> numberOfProcesses;

    // Dynamic input for processes
    for (int i = 0; i < numberOfProcesses; ++i) {
        int pid, priority, burstTime;
        cout << "Enter Process ID: ";
        cin >> pid;
        cout << "Enter Priority (0: High, 1: Medium, 2: Low): ";
        cin >> priority;
        cout << "Enter Burst Time: ";
        cin >> burstTime;

        Process p(pid, priority, burstTime);
        switch (priority) {
            case 0:
                highPriorityQueue.push(p);
                break;
            case 1:
                mediumPriorityQueue.push(p);
                break;
            case 2:
                lowPriorityQueue.push(p);
                break;
            default:
                cout << "Unknown priority for Process ID: " << p.pid << endl;
                break;
        }
    }

    // Execute processes in order of priority: High -> Medium -> Low
    cout << "\nExecuting High Priority Queue:\n";
    while (!highPriorityQueue.empty()) {
        Process p = highPriorityQueue.front();
        highPriorityQueue.pop();
        executeProcess(p);
    }

    cout << "\nExecuting Medium Priority Queue:\n";
    while (!mediumPriorityQueue.empty()) {
        Process p = mediumPriorityQueue.front();
        mediumPriorityQueue.pop();
        executeProcess(p);
    }

    cout << "\nExecuting Low Priority Queue:\n";
    while (!lowPriorityQueue.empty()) {
        Process p = lowPriorityQueue.front();
        lowPriorityQueue.pop();
        executeProcess(p);
    }

    return 0;
}

